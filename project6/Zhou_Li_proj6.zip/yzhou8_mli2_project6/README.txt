AI project6 README
Author: 
Mengwen Li(mli2)
Yihong Zhou(yzhou8)

We implement the optionA using Java.
We didn�t use any external libraries at all. 
The program has 3 classes: Node, RejectSampling and LikelyhoodWeighting. Node contains a value(weight), a name, a status(recording true or false), a restriction variable(indicating it is a evidence true, evidence false, query or none), an array contains all parents� nodes(can trace parents), an array of possibilities(CPT).

The main has a hashmap contains all the information of all nodes. This hashmap is used to add nodes� parents after creating nodes and also used for going through the nodes to pick which node needs to start the sampling.

The whole process of main is:
1.Checking args and get each args
2.Reading files and get the contents
3.Parse the contents of two files and store the information
4.Create nodes
5.Add evidence info and parents to nodes
6.run two sample algorithms

Run this project with following command line:
java -jar project6.jar network.txt query.txt #ofSample

